package com.mani.session12ass3;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by sakshi.banger on 13-10-2016.
 */
public class listfragment extends android.app.Fragment implements AdapterView.OnItemClickListener {
   ListView lvlayouts;
    String Layouts[];

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.list_fragment,container,false);
        lvlayouts=(ListView) view.findViewById(R.id.lvlayouts);
        lvlayouts.setOnItemClickListener(this);
        Layouts=getResources().getStringArray(R.array.layouts);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,Layouts);
        lvlayouts.setAdapter(adapter);
        return view;


    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String name=Layouts[position];
       TextView tvname= (TextView)  getActivity().findViewById(R.id.tvname);
        tvname.setText(name);


    }
}
